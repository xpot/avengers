<?php

namespace app\controllers;
//define('YII_DEBUG', true);
use Yii;
//ini_set('display_errors', true);
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;

class Xyz extends Controller{

	public function display(){
		echo "hello";
	}
}